install.packages("devtools", type = "win.binary")
library(devtools)
install_github("datazoompuc/datazoom.amazonia")
library(datazoom.amazonia)

# Download raw data (raw_data = TRUE) from 2010 (time_period = 2010) 
# Since the data is raw, it will be presented in portuguese.
data <- load_prodes(dataset = "prodes", 
                    raw_data = TRUE,
                    time_period = 2010,
                    language = 'pt')  

# Download treated data (raw_data = FALSE) from 2008 to 2010 (time_period = 2008:2010)
#In this example, the user wanted the data to be in english (language = 'eng')

data <- load_prodes(dataset = "prodes", 
                    raw_data = FALSE,
                    time_period = 2008:2010,
                    language = 'eng')