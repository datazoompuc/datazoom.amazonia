
# Download treated (raw_data = FALSE) data related to the production from permanent and temporary farmed lands (dataset = 'all_crops') by region (geo_level = "region") from 1980 to 1990 (time_period = 1980:1990) in english (language = "eng").
data <- load_pam(dataset = 'all_crops', 
                 raw_data = FALSE, 
                 geo_level = "region", 
                 time_period = 1980:1990, 
                 language = "eng")
# Download raw data (raw_data = TRUE) related to the corn production (dataset = 'corn') by municipality (geo_level = "municipality") from 2010 to 2012 (time_period = 2010:2012) in portuguese (language = "pt").
data <- load_pam(dataset = 'corn', 
                 raw_data = TRUE, 
                 geo_level = "municipality", 
                 time_period = 2010:2012, 
                 language = "pt")