# install.packages("devtools")
install.packages("devtools",type="win.binary")

# Install datazoom.amazonia package 
devtools::install_github("datazoompuc/datazoom.amazonia")

library(datazoom.amazonia)

# Download treated data (raw_data = FALSE) in portuguese (language = "pt").
data <- load_sigmine(dataset = 'sigmine_active', 
                     raw_data = FALSE,
                     language = "pt")