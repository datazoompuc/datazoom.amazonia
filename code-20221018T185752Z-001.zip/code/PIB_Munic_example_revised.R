library(devtools)
install.packages("devtools")

install_github("datazoompuc/datazoom.amazonia")
install.packages("Rtools")
#testing the examples for the data base PIB-Munic

# Download raw data (raw_data = TRUE) on gross domestic product 
# (dataset = 'pibmunic') from the entire country (legal_amazon_only = FALSE) 
# by state (geo_level = 'state') from 2012 (time_period = 2012)
data <- datazoom.amazonia::load_pibmunic(dataset = 'pibmunic',
                      raw_data = TRUE,
                      geo_level = 'state',
                      time_period = 2012,
                      legal_amazon_only = FALSE)
library(readr)
write_rds(data, "PIBmunic_GDP_rawdata_entirecountry_2012_state")
#Problem: the R does not recognize the funcion "load_pibmuniC" alone
#ou need to put the name of the package before


# Download treated data (raw_data = FALSE) on gross domestic product 
# (dataset = 'pibmunic') from the Legal Amazon (legal_amazon_only = TRUE) 
# by municipality (geo_level = 'municipality') from 2012 (time_period = 2012).  
data <-datazoom.amazonia::load_pibmunic(dataset = 'pibmunic',
                      raw_data = FALSE,
                      geo_level = 'municipality',
                      time_period = 2012,
                      legal_amazon_only = TRUE)
#As expected, this example is taking a huge time to load, since its
#based on a municipality level, I'll put is as an issue even if it works,
#since I don't consider it a good example, but a workable one

