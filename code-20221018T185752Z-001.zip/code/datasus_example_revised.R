install.packages("devtools", type = "win.binary")
library(devtools)
install_github("datazoompuc/datazoom.amazonia")
library(datazoom.amazonia)




#DATASUS System of Mortality Information (SIM) data 
#Tested different parameters, all successful

datasus_SIM_raw <- load_datasus(dataset = "datasus_sim_do",
                     time_period = 2010,
                     raw_data = TRUE)


datasus_SIM_treated_municipal_level <- load_datasus(dataset = "datasus_sim_do",
                                time_period = c(2010) ,
                                raw_data = FALSE)

datasus_SIM_individual_variables <- data <- load_datasus(dataset = "datasus_sim_do",
                                                         time_period = 2010,
                                                         raw_data = FALSE,
                                                         keep_all = TRUE)

datasus_SIM_iv_filtered_by_state <- load_datasus(dataset = "datasus_sim_do",
                                     time_period = 2010,
                                     states = c("AM", "PA"),
                                     raw_data = FALSE,
                                     keep_all = TRUE)



#DATASUS National Register of Health Establishment (CNES) data
#Tested 6 out of 13 raw datasets, Teaching Establishments (EE) returned empty data.
#The rest were ok
#Treated beds data also worked

datasus_CNES_lt_treated_AM_PA <- load_datasus(dataset = "datasus_cnes_lt",
                     time_period = 2010,
                     states = c("AM", "PA"),
                     raw_data = FALSE)

datasus_CNES_lt_raw_AM_PA <- load_datasus(dataset = "datasus_cnes_lt",
                                          time_period = 2010,
                                          states = c("AM", "PA"),
                                          raw_data = TRUE)

datasus_CNES_eq_raw_AM_PA <- load_datasus(dataset = "datasus_cnes_eq",
                                          time_period = 2010,
                                          states = c("AM", "PA"),
                                          raw_data = FALSE)

datasus_CNES_rc_raw_AM_PA <- load_datasus(dataset = "datasus_cnes_rc",
                                          time_period = 2010,
                                          states = c("AM", "PA"),
                                          raw_data = FALSE)

datasus_CNES_ef_raw_AM_PA <- load_datasus(dataset = "datasus_cnes_ef",
                                          time_period = 2010,
                                          states = c("AM", "PA"),
                                          raw_data = FALSE)

datasus_CNES_ee_raw_AM_PA <- load_datasus(dataset = "datasus_cnes_ee",
                                          time_period = 2010,
                                          states = c("AM", "PA"),
                                          raw_data = FALSE)

datasus_CNES_ep_raw_AM_PA <- load_datasus(dataset = "datasus_cnes_ep",
                                          time_period = 2010,
                                          states = c("AM", "PA"),
                                          raw_data = FALSE)

#DATASUS System of Hospital Information (SIH) data
#Testes raw and treated data, both successful

datasus_SIH_raw_data <- load_datasus(dataset = "datasus_sih",
                     time_period = 2010,
                     states = "AM",
                     raw_data = TRUE)

datasus_SIH_treated_data <- load_datasus(dataset = "datasus_sih",
                     time_period = 2010,
                     states = "AM",
                     raw_data = FALSE)


library(readr)

write_rds(datasus_SIM_raw, "SIM_raw")
write_rds(datasus_SIM_treated, "SIM_treated")
write_rds(datasus_SIM_individual_variables, "SIM_individual_variables_treated")
write_rds(datasus_CNES_lt_treated_AM_PA, "CNES_beds_treated")
write_rds(datasus_SIH_raw_data, "SIH_raw_data")
write_rds(datasus_SIH_treated_data, "SIH_treated_data")



#Only saved in .RDS format the examples available in the GitHub README of the package.
#The SIM examples were not filtered by state in order to test whether the data of all of them was available and functional.
