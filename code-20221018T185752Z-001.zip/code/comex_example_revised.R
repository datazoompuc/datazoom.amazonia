
#Download treated (raw_data = FALSE) exports data by municipality (dataset = "comex_export_mun") from 2020 to 2021 (time_period = 2020:2021)
data <- load_br_trade(dataset = "comex_export_mun", 
                      raw_data = FALSE, 
                      time_period = 2020:2021)
#Download treated (raw_data = FALSE) imports data by producer (dataset = "comex_import_prod") from 2020 to 2021 (time_period = 2020:2021) 
data <- load_br_trade(dataset = "comex_import_prod",
                      raw_data = FALSE, 
                      time_period = 2020:2021)