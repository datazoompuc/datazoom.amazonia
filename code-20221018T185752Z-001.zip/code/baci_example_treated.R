install.packages("devtools", type = "win.binary")
library(devtools)
install_github("datazoompuc/datazoom.amazonia")
library(datazoom.amazonia)


baci_treated <- load_baci(dataset = "HS92", raw_data = FALSE, time_period = 2016,
                        language = "pt")