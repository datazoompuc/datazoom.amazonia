install.packages("devtools", type = "win.binary")
library(devtools)
install_github("datazoompuc/datazoom.amazonia")
library(datazoom.amazonia)


#There is only this set of parameters available for use, so I named it "IMAZON"

IMAZON <- load_imazon(dataset = "imazon_shp", raw_data = TRUE,
                    geo_level = "municipality", language = "pt")