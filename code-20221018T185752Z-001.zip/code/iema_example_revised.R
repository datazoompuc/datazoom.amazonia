# Install.packages("devtools")
install.packages("devtools",type="win.binary")

# Install datazoom.amazonia package 
devtools::install_github("datazoompuc/datazoom.amazonia")

library(datazoom.amazonia)

# Download treated data (raw_data = FALSE)
data <- load_iema(dataset = "iema", raw_data = FALSE,
                  geo_level = "municipality", language = "pt")

# Download treated data in english
data <- load_iema(dataset = "iema", raw_data = FALSE,
                  geo_level = "municipality", language = "eng")


#Suggestion: include "install.packages("googledrive")" in the example, since it is requested when you try to download the data

