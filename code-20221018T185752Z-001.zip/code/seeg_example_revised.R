# Install packages("devtools")
install.packages("devtools",type="win.binary")

# Install datazoom.amazonia package 
devtools::install_github("datazoompuc/datazoom.amazonia")

library(datazoom.amazonia)

# Download raw data (raw_data = TRUE) of greenhouse gases (dataset = "seeg") by municipality (geo_level = "municipality")
data <- load_seeg(dataset = "seeg", 
                  raw_data = TRUE,
                  geo_level = "municipality")

# Download treated data (raw_data = FALSE) of industry greenhouse gases (dataset = "seeg_industry") by state (geo_level = "state")
data <- load_seeg(dataset = "seeg_industry", 
                  raw_data = FALSE,
                  geo_level = "state")

