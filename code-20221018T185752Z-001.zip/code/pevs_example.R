install.packages("devtools", type = "win.binary")
library(devtools)
install_github("datazoompuc/datazoom.amazonia")
library(datazoom.amazonia)

#example 1
# Download treated (raw_data = FALSE) silviculture data (dataset = 'pevs_silviculture') by state (geo_level = 'state') from 2012 (time_period =  2012) in portuguese (language = "pt")
data <- load_pevs(dataset = 'pevs_silviculture', 
                  raw_data = FALSE,
                  geo_level = 'state', 
                  time_period = 2012, 
                  language = "pt")

#example 2
# Download raw (raw_data = TRUE) forest crops data (dataset = 'pevs_forest_crops') by municipality (geo_level = 'municipality') from 2012 to 2013 (time_period = 2012:2013) in english.
#too big to run
data <- load_pevs(dataset = 'pevs_forest_crops', 
                  raw_data = TRUE, 
                  geo_level = "municipality", 
                  time_period = 2012:2013)

#alternative suggestion
#example 2
# Download raw (raw_data = TRUE) forest crops data (dataset = 'pevs_forest_crops') by region (geo_level = 'regioon') from 2012 to 2013 (time_period = 2012:2013) in english.
data <- load_pevs(dataset = 'pevs_forest_crops', 
                 raw_data = TRUE, 
                 geo_level = "region", 
                 time_period = 2012:2013)