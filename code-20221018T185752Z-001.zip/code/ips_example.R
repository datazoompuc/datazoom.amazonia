install.packages("devtools", type = "win.binary")
library(devtools)
install_github("datazoompuc/datazoom.amazonia")
library(datazoom.amazonia)

# Download raw data from 2014
#raw data is only available in portuguese
data <- load_ips(dataset = "all", raw_data = TRUE, time_period = 2014, language = "pt")

# Download treated deforest data from both year (time_period = 2014:2018) in english
#runs error
data <- load_ips(dataset = "deforest", raw_data = FALSE,
                 time_period = 2014:2018)
