library(readr)
library(tidyverse)
library(readxl)

#######################
##Sistemas Isolados
#######################

###Consumo Mensal de energia Eletrica por classe
readxl::read_xls(path = "./SistemasIsolados/CONSUMO MENSAL DE ENERGIA ELÉTRICA POR CLASSE.xls") %>%
  write_rds("sistemas_isolados_consumo_mensal_de_energia_eletrica_por_classe.rds")

###Despesas Estimadas no Orçamento da CDE
readxl::read_xlsx(path = "./SistemasIsolados/Despesas Estimadas no Orçamento da CDE (R$).xlsx") %>%
   write_rds("sistemas_isolados_despesas_estimadas_no_orcamento_da_cde.rds")

#######################
##Geracao Distribuida
#######################

###BD_SIGA
readxl::read_xlsx(path = "./GeracaoDistribuida/BD_SIGA.xlsx") %>%
  write_rds("geracao_distribuida_BD_SIGA.rds")

###Empreendimento geracao distribuida
readr::read_csv(file =  "./GeracaoDistribuida/empreendimento-geracao-distribuida.csv") %>%
  write_rds("geracao_distribuida_empreendimento_geracao_distribuida.rds")

#######################
##AMZ Exporta Energia
#######################

###Anuario Estatistico de Energia Eletrica 2022 - Workbook
readxl::read_xlsx(path = "./AMZexportaenergia/Anuario Estatistico de Energia Eletrica 2022 - Workbook.xlsx") %>%
  write_rds("amz_exporta_energia_anuario_estatistico_de_energia_eletrica_2022.rds")

###Capítulo 8 - (Dados Estaduais)
readxl::read_xls(path = "./AMZexportaenergia/Capitulo8DadosEstaduais.xls") %>%
  write_rds("amz_exporta_energia_capitulo_8_dados_estaduais.rds")
