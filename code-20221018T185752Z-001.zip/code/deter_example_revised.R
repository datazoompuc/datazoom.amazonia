# Download treated data (raw_data = TRUE) from Amazonia (dataset = "deter_amz")
deter_amz <- load_deter(dataset = 'deter_amz',
                        raw_data = FALSE)
library(readr)
write_rds(deter_amz, "deter_amz_treated")
