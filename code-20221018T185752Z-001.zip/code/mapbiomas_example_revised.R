#Download treated (raw_data = FALSE) Mapbiomas Cover data (dataset = "mapbiomas_cover") in english (language = "eng") 
# The example is at the highest aggregation level (cover_level = 0)
data = load_mapbiomas(dataset = "mapbiomas_cover", 
                      raw_data = FALSE,
                      language = "eng", 
                      cover_level = 0)

#Download treated (raw_data = FALSE) Mapbiomas Transition (dataset = "mapbiomas_transition") 
#In the example, the data selected is in portuguese (language = "pt")
data = load_mapbiomas(dataset = "mapbiomas_transition", 
                      raw_data = FALSE,
                      geo_level = "state",
                      language = "pt")
#Download treated data (raw_data = FALSE) on mining (dataset = "mapbiomas_mining")
#This example selects indigenous lands (geo_level = "indigenous_land") and is in englis
data = load_mapbiomas(dataset = "mapbiomas_mining", 
                      raw_data = FALSE, 
                      geo_level = "indigenous_land",
                      language = "eng")