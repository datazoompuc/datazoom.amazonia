install.packages("devtools", type = "win.binary")
library(devtools)
install_github("datazoompuc/datazoom.amazonia")
library(datazoom.amazonia)

# download treated data (raw_data = TRUE) related to forest degradation from 2010 to 2012 (time_period = 2010:2012).
#language is set to english

data <- load_degrad(dataset = 'degrad', 
                    raw_data = FALSE,
                    time_period = 2010:2012)