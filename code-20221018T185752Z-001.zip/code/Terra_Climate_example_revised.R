install.packages("devtools", type = "win.binary")

library(devtools)

devtools::install_github("datazoompuc/datazoom.amazonia")

  
#Terra Climate
  
  
# Downloading maximum temperature data from 2000 to 2020
  
max_temp <- datazoom.amazonia::load_climate(dataset = "max_temperature", time_period = 2000:2020)

summary(max_temp)

# Downloading precipitation data only for the legal Amazon in 2010

amz_precipitation <- datazoom.amazonia::load_climate(dataset = "precipitation",
                                  time_period = 2010,
                                  legal_amazon_only = TRUE)
#First error is that the package is not able by himself to perform the said function,
#my R keeps queriring the package "terra" to be installed to use this function
install.packages("terra")

#testing again

# Downloading maximum temperature data from 2000 to 2020

max_temp <- datazoom.amazonia::load_climate(dataset = "max_temperature", time_period = 2000:2020)

#This example is not coded wrong, but is just delivers a way too big database(488 million observations) for an example, generating a
#vector of approximatelly 785 MB, but when I ran less years, such as 1 or 2, the example worked.

# Downloading precipitation data only for the legal Amazon in 2010

amz_precipitation <- load_climate(dataset = "precipitation",
                                                     time_period = 2010,
                                                     legal_amazon_only = TRUE)
#There was an error in the second example


write_rds(max_temp, "TerraClimate_max_temp")

