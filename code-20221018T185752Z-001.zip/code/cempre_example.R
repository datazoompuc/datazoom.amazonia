install.packages("devtools", type = "win.binary")
library(devtools)
install_github("datazoompuc/datazoom.amazonia")
library(datazoom.amazonia)


# Download raw data (raw_data = TRUE) with the aggregation level being the country (geo_level = "country") from 2008 to 2010 (time_period = 2008:2010). 
# In this example, the user did not want to visualize data by sector (sectors = FALSE) and the user also did not want the data to be restricted to the Legal Amazon area (legal_amazon_only = FALSE).
data <- load_cempre(dataset = "cempre", 
                    raw_data = TRUE,
                    geo_level = "country",
                    language = "pt",
                    time_period = 2008:2010,
                    sectors = FALSE,
                    legal_amazon_only = FALSE) 

#This example included geo_level = "state". However, showing data only for the Legal Amazon is only available at the "municipality" level (geo_level = "municipality").
# Download treated data (raw_data = FALSE) by municipality (geo_level = "municipality") from 2008 to 2010 (time_period = 2008:2010) in portuguese (language = "pt").. 
# In this example, the user wanted to visualize data by sector (sectors = TRUE) and the user also wanted the data to be restricted to the Legal Amazon area (legal_amazon_only = TRUE).
#too big to run
data <- load_cempre(dataset = "cempre", 
                    raw_data = FALSE,
                    geo_level = "municipality", 
                    time_period = 2008:2010,
                    language = "pt",
                    sectors = TRUE,
                    legal_amazon_only = TRUE) 

#alternative suggestion

#example 1
# Download raw data (raw_data = TRUE) with the aggregation level being the states (geo_level = "state") from 2008 to 2010 (time_period = 2008:2010). 
# In this example, the user wanted to visualize data by sector (sectors = TRUE), but the user did not want the data to be restricted to the Legal Amazon area (legal_amazon_only = FALSE).
#The chosen language is portuguese.
data <- load_cempre(dataset = "cempre", 
                    raw_data = TRUE,
                    geo_level = "state",
                    language = "pt",
                    time_period = 2008:2010,
                    sectors = FALSE,
                    legal_amazon_only = FALSE) 


#example 2
# Download treated data (raw_data = FALSE) with the aggregation level being the country (geo_level = "country") in 2009 (time_period = 2009). 
# In this example, the user wanted to visualize data by sector (sectors = TRUE), but not to restrict it to the Legal Amazon area (legal_amazon_only = FALSE).
data <- load_cempre(dataset = "cempre", 
                    raw_data = FALSE,
                    geo_level = "country", 
                    time_period = 2009,
                    sectors = TRUE,
                    legal_amazon_only = FALSE)